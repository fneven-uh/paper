from typing import Optional, Set, Tuple, cast
from robustness.program import BTPBranch, BTPLoop, BTPStatementType, BTProgram, Program, Query, QueryType, unfold_programset, BTPStatement
from robustness import sumgraph as sg
from robustness import synthetic
from robustness import smallbank as sb
from robustness import tpcc
from robustness.schema import Attribute

TABLE_HEADER = """\\begin{tabular}[t]{| l | l | l | l | l | l |}
\\hline
$q$ & $\\type{q}$ &  $\\rel{q}$ & $\\predset{q}$ & $\\obsset{q}$ & $\\modset{q}$\\\\
\\hline
\\hline
"""

TABLE_FOOTER = "\\end{tabular}\n"

def UPDATE_NAME(name: str): return name.replace("_", "\\_")

def convert_basic_statement(q: Query, stm_counter: int) -> str:
    result = f"$q_{{{stm_counter}}}$ & "
    qtype = ""
    predset: Optional[Set[Attribute]] = None
    readset: Optional[Set[Attribute]] = None
    writeset: Optional[Set[Attribute]] = None
    if q.querytype == QueryType.INSERT:
        qtype = "qins"
        writeset = q.modification_set
    elif q.querytype == QueryType.SELECT:
        readset = q.observation_set
        if len(q.predicate_set) == 0:
            qtype += "qksel"
        else:
            qtype += "qpsel"
            predset = q.predicate_set
    elif q.querytype == QueryType.UPDATE:
        readset = q.observation_set
        writeset = q.modification_set
        if len(q.predicate_set) == 0:
            qtype += "qkupd"
        else:
            qtype += "qpupd"
            predset = q.predicate_set
    elif q.querytype == QueryType.DELETE:
        writeset = q.modification_set
        if len(q.predicate_set) == 0:
            qtype += "qkdel"
        else:
            qtype += "qpdel"
            predset = q.predicate_set
    result += f"$\\{qtype}$ & {UPDATE_NAME(q.relation.name)} & "
    if predset is None:
        result += "$\\bot$ & "
    else:
        attr_names = ", ".join(sorted(UPDATE_NAME(p.name) for p in predset))
        result += f"\\{{{attr_names}\\}} & "
    if readset is None:
        result += "$\\bot$ & "
    else:
        attr_names = ", ".join(sorted(UPDATE_NAME(p.name) for p in readset))
        result += f"\\{{{attr_names}\\}} & "
    if writeset is None:
        result += "$\\bot$\\\\\n"
    else:
        attr_names = ", ".join(sorted(UPDATE_NAME(p.name) for p in writeset))
        result += f"\\{{{attr_names}\\}}\\\\\n"
    result += "\\hline\n"
    return  result

def convert_statement(statement: BTPStatement, stm_counter: int) -> Tuple[str, int]:
    result = ""
    if statement.get_type() == BTPStatementType.STATEMENT:
        q = cast(Query, statement)
        result += convert_basic_statement(q, stm_counter)
        stm_counter += 1
    elif statement.get_type() == BTPStatementType.LOOP:
        loop = cast(BTPLoop, statement)
        for stm in loop.subprogram:
            s, stm_counter = convert_statement(stm, stm_counter)
            result += s
    elif statement.get_type() == BTPStatementType.BRANCH:
        branch = cast(BTPBranch, statement)
        for stm in branch.subprogram_if:
            s, stm_counter = convert_statement(stm, stm_counter)
            result += s
        for stm in branch.subprogram_else:
            s, stm_counter = convert_statement(stm, stm_counter)
            result += s
    else:
        print(statement.get_type())
        pass #TODO
    return result, stm_counter

def convert_program(program: BTProgram, stm_counter: int) -> Tuple[str, int]:
    result = f"\\multicolumn{{6}}{{|c|}}{{\\bf {program.name}}}\\\\\n\\hline\n"

    for stm in program.queries:
        s, stm_counter = convert_statement(stm, stm_counter)
        result += s
    return result, stm_counter

def convert_to_tex(programs: Set[BTProgram]) -> str:
    result = TABLE_HEADER
    counter = 1
    for program in sorted(programs, key=lambda p: p.name):
        s, counter = convert_program(program, counter)
        result += s
    result += TABLE_FOOTER
    return result
    


def convert_auction_benchmark(n: int) -> None:
    _, programs = synthetic.create_scaled_program(n)
    converted = convert_to_tex(programs)
    print(converted)


def convert_smallbank_benchmark() -> None:
    converted = convert_to_tex(sb.programs)
    print(converted)


def convert_tpcc_benchmark() -> None:
    converted = convert_to_tex(tpcc.programs)
    print(converted)


if __name__ == "__main__":
    #convert_auction_benchmark(1)
    #convert_smallbank_benchmark()
    convert_tpcc_benchmark()