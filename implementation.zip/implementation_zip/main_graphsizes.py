from typing import Set, Tuple
from robustness import smallbank
from robustness import tpcc
from robustness import synthetic
from robustness.program import BTProgram, unfold_programset
from robustness.sumgraph import construct_summary_graph


def graph_size(programs: Set[BTProgram]) -> Tuple[int, int, int]:
    # unfold BTPs into LTPs
    linear = unfold_programset(programs)
    # Construct summary graph
    graph = construct_summary_graph(linear)
    return (len(graph.nodes), len(graph.edges), len(graph.counterflow_edges))


def generate_graphsize_table() -> str:
    benchmarks = [smallbank.programs, tpcc.programs,
                  synthetic.create_scaled_program(1)[1]]
    size_names = ["nodes", "edges", "counterflow edges"]
    bench_results = [graph_size(b) for b in benchmarks]
    result = " & SmallBank & TPC-C & Auction\\\\\n"
    for name, *values in zip(size_names, *bench_results):
        result += f"{name}"
        for value in values:
            result += f" & {value}"
        result += "\\\\\n"
    return result


if __name__ == "__main__":
    print(generate_graphsize_table())
