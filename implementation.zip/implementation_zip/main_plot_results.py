"""
Generates plots from raw data.
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

PALETTE_1COLOR = sns.color_palette(("#3571aa",), desat=1)
PALETTE_1COLORB = sns.color_palette(("#d96355",), desat=1)
PALETTE_2COLOR = sns.color_palette(("#d96355", "#8ec3e4", "#00a3c4"), desat=1)
PALETTE_3COLOR = sns.color_palette(("#3571aa", "#decb4a", "#d96355", "#8ec3e4", "#00a3c4"), desat=1)
PALETTE_4COLOR = sns.color_palette(("#3571aa", "#8ec3e4", "#decb4a", "#d96355", "#00a3c4"), desat=1)
REPLACEMENT_LEGEND = {
    "RC_PROM": "RC(CS)", "RC_ACC_PROM": "RC(A)", #smallbank
    "RC_WHC": "RC(WHC)", "RC_CO": "RC(CO)"       #TPC-C
}


def plot_results(data: pd.DataFrame):
    fig = plt.figure(constrained_layout=True, dpi=600, figsize=(7,3))
    heights = [4]
    widths= [5,5]
    spec = fig.add_gridspec(ncols=2, nrows=1, height_ratios=heights, width_ratios=widths)
    
    ax1 = fig.add_subplot(spec[0, 0])
    sns.barplot(x="scaling", y="time",
                data=data,
                errwidth=1, capsize=.1, ax=ax1, palette=PALETTE_1COLOR, saturation=1)
    #plt.xlabel("Scaling Factor")
    plt.xlabel("Scaling Factor $n$")
    plt.ylabel("Time (s)")

    # ax2 = fig.add_subplot(spec[1, 0])
    # melted = data.melt(id_vars=["scaling","time","try"], value_vars=["nodes","edges"],
    #     var_name="numbertype", value_name="number")
    # sns.barplot(x="scaling", y="number",
    #             hue="numbertype", data=melted,
    #             ci=None, # No confidence interval needed here
    #             palette=PALETTE_2COLOR, saturation=1)
    # plt.xlabel("Scaling Factor")
    # plt.ylabel("")

    ax2 = fig.add_subplot(spec[0, 1])
    sns.barplot(x="scaling", y="edges",
                data=data,
                ci=None, # No confidence interval needed here
                palette=PALETTE_1COLORB, saturation=1)
    plt.xlabel("Scaling Factor $n$")
    plt.ylabel("Number of Edges")
    return fig


def plot_throughput_and_abort_rate(data, x_axis, x_label, size=(4, 4), ncol=3, hue="isolation_level", palette=PALETTE_3COLOR):
    
    fig = plt.figure(constrained_layout=True, dpi=600, figsize=size)
    heights = [4, 4]
    spec = fig.add_gridspec(ncols=1, nrows=2, height_ratios=heights)
    ax1 = fig.add_subplot(spec[0, 0])
    
    sns.barplot(x=x_axis, y="throughput",
                hue=hue, data=data,
                errwidth=1, capsize=.1, ax=ax1, palette=palette, saturation=1)
    plt.xlabel(x_label)
    plt.ylabel("Time (s)")
    box = (0.5, 1.05)
    colspacing = None
    if ncol == 4:
        box = (0.45, 1.05)
        colspacing = 1.1
    plt.legend(title=None, loc="lower center", bbox_to_anchor=box, ncol=ncol, columnspacing=colspacing)
    
    ax2 = fig.add_subplot(spec[1, 0])
    
    sns.barplot(x=x_axis, y="abort_rate",
                hue=hue, data=data,
                errwidth=1, capsize=.1,
                palette=palette, saturation=1)
    plt.xlabel(x_label)
    plt.ylabel("Aborts / second")
    plt.legend().remove()
    
    return fig


def plot_experiment(exp_name: str):
    data = pd.read_csv(f"results/{exp_name}.csv")
    fig = plot_results(data)
    fig.savefig(f"results/fig_{exp_name}.png")


def main():
    plot_experiment("experiment_1_6_1_10")
    plot_experiment("experiment_5_51_5_10")

if __name__ == '__main__':
    main()
