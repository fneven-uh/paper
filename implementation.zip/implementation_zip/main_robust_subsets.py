import itertools
from enum import Enum, auto
from typing import List, Set
from robustness import smallbank
from robustness import tpcc
from robustness import synthetic
from robustness.program import BTProgram, unfold_programset
from robustness.sumgraph import construct_summary_graph
from robustness.robustsufcond import DetectionMethod
from robustness import robustsufcond as rsc


class Setting(Enum):
    # Tuple level conflicts, no FK constraints
    TUPLE_CONFLICT = auto()
    # Attr level conflicts, no FK constraints
    ATTR_CONFLICT = auto()
    # Tuple level conflicts + FK constraints
    TUPLE_FK_CONSTRAINTS = auto()
    # Attr level conflicts + FK constraints
    ATTR_FK_CONSTRAINTS = auto()


NAME_LOOKUP = {
    # SmallBank
    "Amalgamate": "Am",
    "Balance": "Bal",
    "DepositChecking": "DC",
    "TransactSavings": "TS",
    "WriteCheck": "WC",
    # TPC-C
    "Delivery": "Del",
    "NewOrder": "NO",
    "OrderStatus": "OS",
    "Payment": "Pay",
    "StockLevel": "SL",
    # Auction
    "FindBids_1_": "FB",
    "PlaceBid_1_": "PB",
}


def detect_robustness(programs: Set[BTProgram],
                      method: DetectionMethod,
                      setting: Setting) -> bool:
    # unfold BTPs into LTPs
    linear = unfold_programset(programs)
    # depending on setting, remove details in programs
    if setting == Setting.TUPLE_CONFLICT or setting == Setting.ATTR_CONFLICT:
        # No FK constraints
        for prog in linear:
            prog.constraints = []
    if setting == Setting.TUPLE_CONFLICT or setting == Setting.TUPLE_FK_CONSTRAINTS:
        # tuple level conflicts: all nonempty attribute sets should contain all attributes
        for prog in linear:
            for q in prog.queries:
                if len(q.predicate_set) > 0:
                    q.predicate_set = set(q.relation.attributes)
                if len(q.observation_set) > 0:
                    q.observation_set = set(q.relation.attributes)
                if len(q.modification_set) > 0:
                    q.modification_set = set(q.relation.attributes)
    # Construct summary graph and apply robustness detection
    graph = construct_summary_graph(linear)
    robust = rsc.is_robust(graph, method)
    return robust


def max_robust_subsets(programs: Set[BTProgram],
                       method: DetectionMethod,
                       setting: Setting) -> List[Set[BTProgram]]:
    max_sets: List[Set[BTProgram]] = []
    for i in range(len(programs), 0, -1):
        for combi in itertools.combinations(programs, i):
            combi_set = set(combi)
            robust = detect_robustness(combi_set, method, setting)
            if robust:
                # only add if no robust superset
                for s in max_sets:
                    if s.issuperset(combi_set):
                        break
                else:
                    max_sets.append(combi_set)
    return max_sets


def generate_robustness_table(method: DetectionMethod) -> str:
    benchmarks = [smallbank.programs, tpcc.programs,
                  synthetic.create_scaled_program(1)[1]]
    setting_names = ["tpl confl", "attr confl",
                     "tpl confl + FK", "attr confl + FK"]
    settings = [Setting.TUPLE_CONFLICT, Setting.ATTR_CONFLICT,
                Setting.TUPLE_FK_CONSTRAINTS, Setting.ATTR_FK_CONSTRAINTS]
    result = " & SmallBank & TPC-C & Auction\\\\\n"
    for name, setting in zip(setting_names, settings):
        result += f"{name}"
        for benchmark in benchmarks:
            result += " & "
            max_sets = max_robust_subsets(benchmark, method, setting)
            for mset in max_sets:
                sorted_names = sorted(p.name for p in mset)
                result += "\\{"
                for sname in sorted_names:
                    result += f"{NAME_LOOKUP[sname]}, "
                result = result[:-2] + "\\}, "
            result = result[:-2]
        result += "\\\\\n"
    return result


if __name__ == "__main__":
    print(generate_robustness_table(DetectionMethod.ADVANCED_CYCLE))
    print()
    print(generate_robustness_table(DetectionMethod.COUNTERFLOW_CYCLE))
