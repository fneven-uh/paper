import timeit
from typing import Set
from robustness import smallbank
from robustness import tpcc
from robustness import synthetic
from robustness.program import BTProgram, unfold_programset
from robustness.sumgraph import construct_summary_graph
from robustness.robustsufcond import DetectionMethod
from robustness import robustsufcond as rsc


def detect_robustness(programs: Set[BTProgram]) -> bool:
    linprogs = unfold_programset(programs)
    graph = construct_summary_graph(linprogs)
    robust = rsc.is_robust(graph, DetectionMethod.ADVANCED_CYCLE)
    #print(f"-> robust?: {robust}")
    return robust


def timing_experiment(start: int, stop: int, step: int, num_tries: int) -> None:
    with open(f"results/experiment_{start}_{stop}_{step}_{num_tries}.csv", "w") as fp:
        fp.write("scaling,time,try,nodes,edges,counterflow,noncounterflow\n")
        for scaling in range(start, stop, step):
            print(f"scaling factor {scaling}:")
            for n in range(num_tries):
                _, progs = synthetic.create_scaled_program(scaling)
                # measure execution time
                timing = timeit.timeit(lambda: detect_robustness(progs),
                                       number=1, globals=globals())
                # construct graph again for info
                linprogs = unfold_programset(progs)
                graph = construct_summary_graph(linprogs)
                # write result to file
                fp.write(f"{scaling},{timing:.3f},{n},{len(graph.nodes)},{len(graph.edges)},"
                         f"{len(graph.counterflow_edges)},{len(graph.non_counterflow_edges)}\n")
                print(f"time: {timing:.2f}s")


if __name__ == "__main__":
    timing_experiment(1, 6, 1, 10)
    timing_experiment(5, 51, 5, 10)
