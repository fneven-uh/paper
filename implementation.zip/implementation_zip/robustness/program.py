from __future__ import annotations
from dataclasses import dataclass
from enum import Enum, auto
from typing import List, Optional, Set, Tuple, cast
from .schema import Attribute, Relation, ForeignKey


class QueryType(Enum):
    SELECT = auto()
    UPDATE = auto()
    INSERT = auto()
    DELETE = auto()


class BTPStatementType(Enum):
    STATEMENT = auto()
    LOOP = auto()
    BRANCH = auto()


class BTPStatement:
    def get_type(self) -> BTPStatementType:
        raise NotImplementedError()


@ dataclass
class Query(BTPStatement):
    position: int
    querytype: QueryType
    relation: Relation
    observation_set: Set[Attribute]
    modification_set: Set[Attribute]
    predicate_set: Set[Attribute]

    def __post_init__(self):
        # verify that the accessed attributes agree with the relation the query is over
        for attr in self.observation_set | self.modification_set | self.predicate_set:
            assert attr.relation == self.relation

    def __hash__(self) -> int:
        return hash((self.position, self.relation))

    def get_type(self) -> BTPStatementType:
        return BTPStatementType.STATEMENT


@ dataclass
class BTPLoop(BTPStatement):
    subprogram: List[BTPStatement]

    def get_type(self) -> BTPStatementType:
        return BTPStatementType.LOOP


@ dataclass
class BTPBranch(BTPStatement):
    subprogram_if: List[BTPStatement]
    subprogram_else: List[BTPStatement]

    def get_type(self) -> BTPStatementType:
        return BTPStatementType.BRANCH


@dataclass
class ForeignKeyConstr:
    source: Query
    target: Query
    foreign_key: ForeignKey

    def __post_init__(self):
        # verify the relations specified by the foreign key
        assert self.source.relation == self.foreign_key.source
        assert self.target.relation == self.foreign_key.target


@dataclass
class Program:
    name: str
    queries: List[Query]
    constraints: List[ForeignKeyConstr]

    def __hash__(self) -> int:
        return hash(self.name)

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return self.name


@dataclass
class BTProgram:
    name: str
    queries: List[BTPStatement]
    constraints: List[ForeignKeyConstr]

    def __hash__(self) -> int:
        return hash(self.name)

    def __str__(self) -> str:
        return self.name

    def __repr__(self) -> str:
        return self.name


class ProgramFactory:

    def __init__(self, name: str) -> None:
        self.name = name
        self.queries: List[Query] = []
        self.fk_constraints: List[ForeignKeyConstr] = []

    def add_query(
            self,
            querytype: QueryType,
            relation: Relation,
            observation_set: Set[Attribute] = None,
            modification_set: Set[Attribute] = None,
            predicate_set: Set[Attribute] = None
    ) -> Query:
        pos = len(self.queries) + 1
        if observation_set is None:
            observation_set = set()
        if modification_set is None:
            modification_set = set()
        if predicate_set is None:
            predicate_set = set()
        query = Query(pos, querytype, relation, observation_set,
                      modification_set, predicate_set)
        self.queries.append(query)
        return query

    def add_fk_constraint(self, source: Query, target: Query, foreignkey: ForeignKey) -> None:
        constraint = ForeignKeyConstr(source, target, foreignkey)
        self.fk_constraints.append(constraint)

    def create_program(self) -> Program:
        return Program(self.name, self.queries, self.fk_constraints)


class BTProgramFactory:
    def __init__(self, name: str) -> None:
        self.name = name
        self.statements_stack: List[Tuple[Optional[BTPStatementType],
                                          Optional[BTPStatement],
                                          List[BTPStatement]]] = [(None, None, [])]
        self.fk_constraints: List[ForeignKeyConstr] = []
        self.next_pos = 1

    def add_query(
            self,
            querytype: QueryType,
            relation: Relation,
            observation_set: Set[Attribute] = None,
            modification_set: Set[Attribute] = None,
            predicate_set: Set[Attribute] = None
    ) -> Query:
        if observation_set is None:
            observation_set = set()
        if modification_set is None:
            modification_set = set()
        if predicate_set is None:
            predicate_set = set()
        query = Query(self.next_pos, querytype, relation, observation_set,
                      modification_set, predicate_set)
        self.next_pos += 1
        self.statements_stack[-1][2].append(query)
        return query

    def start_if(self) -> None:
        q = BTPBranch([], [])
        self.statements_stack[-1][2].append(q)
        self.statements_stack.append(
            (BTPStatementType.BRANCH, q, q.subprogram_if))

    def start_else(self) -> None:
        qtype, q, lst = self.statements_stack.pop()
        branch = cast(BTPBranch, q)
        assert qtype == BTPStatementType.BRANCH and lst is branch.subprogram_if
        self.statements_stack.append(
            (BTPStatementType.BRANCH, branch, branch.subprogram_else))

    def end_if(self) -> None:
        qtype, _, _ = self.statements_stack.pop()
        assert qtype == BTPStatementType.BRANCH

    def start_loop(self) -> None:
        q = BTPLoop([])
        self.statements_stack[-1][2].append(q)
        self.statements_stack.append((BTPStatementType.LOOP, q, q.subprogram))

    def end_loop(self) -> None:
        qtype, _, _ = self.statements_stack.pop()
        assert qtype == BTPStatementType.LOOP

    def add_fk_constraint(self, source: Query, target: Query, foreignkey: ForeignKey) -> None:
        constraint = ForeignKeyConstr(source, target, foreignkey)
        self.fk_constraints.append(constraint)

    def create_program(self) -> BTProgram:
        qtype, q, lst = self.statements_stack.pop()
        assert qtype is None and q is None and len(self.statements_stack) == 0
        return BTProgram(self.name, lst, self.fk_constraints)


def unfold_programset(programs: Set[BTProgram]) -> Set[Program]:
    result: Set[Program] = set()
    for prog in programs:
        result |= unfolded(prog)
    return result


def unfolded(program: BTProgram) -> Set[Program]:
    # if linear: convert to linear
    if _is_linear(program):
        converted = _convert_linear(program)
        return set([converted])
    # otherwise: 3 copies up to first special statement
    prog1 = BTProgram(program.name + "1", [], program.constraints)
    prog2 = BTProgram(program.name + "2", [], program.constraints)
    prog3 = BTProgram(program.name + "3", [], program.constraints)
    i = 0
    while program.queries[i].get_type() == BTPStatementType.STATEMENT:
        prog1.queries.append(program.queries[i])
        prog2.queries.append(program.queries[i])
        prog3.queries.append(program.queries[i])
        i += 1
    # special statement: fill in 2 (branching) or 3 copies
    if program.queries[i].get_type() == BTPStatementType.BRANCH:
        branch = cast(BTPBranch, program.queries[i])
        for q1 in branch.subprogram_if:
            prog1.queries.append(q1)
        for q2 in branch.subprogram_else:
            prog2.queries.append(q2)
    else:  # program.queries[i].get_type() == BTPStatementType.LOOP:
        loop = cast(BTPLoop, program.queries[i])
        for q in loop.subprogram:
            prog2.queries.append(q)
            prog3.queries.append(q)
        for q in loop.subprogram:
            prog3.queries.append(q)
    # remaining statements
    for q in program.queries[i+1:]:
        prog1.queries.append(q)
        prog2.queries.append(q)
        prog3.queries.append(q)
    if program.queries[i].get_type() == BTPStatementType.BRANCH:
        return unfolded(prog1) | unfolded(prog2)
    else:
        return unfolded(prog1) | unfolded(prog2) | unfolded(prog3)


def _is_linear(program: BTProgram) -> bool:
    for q in program.queries:
        if q.get_type() != BTPStatementType.STATEMENT:
            return False
    return True


def _convert_linear(prog: BTProgram) -> Program:
    # keeps track of mapping
    pairs: List[Tuple[Query, Query]] = []
    f = ProgramFactory(prog.name)
    for q_old in prog.queries:
        q = cast(Query, q_old)
        q_new = f.add_query(q.querytype, q.relation,
                            q.observation_set, q.modification_set, q.predicate_set)
        pairs.append((q, q_new))
    # handle foreign key constraints
    for fk in prog.constraints:
        source_q = [t[1] for t in pairs if t[0] is fk.source]
        target_q = [t[1] for t in pairs if t[0] is fk.target]
        if len(target_q) > 1:
            raise NotImplementedError(
                "Target of fk constraint must be outside loops")
        for s in source_q:
            for t in target_q:
                f.add_fk_constraint(s, t, fk.foreign_key)
    return f.create_program()
