from enum import Enum, auto
from typing import Dict, Tuple
from robustness.sumgraph import SummaryGraph, Node
import timeit

class DetectionMethod(Enum):
    COUNTERFLOW_CYCLE = auto()
    ADVANCED_CYCLE = auto()


def is_robust(graph: SummaryGraph, method: DetectionMethod) -> bool:
    if method == DetectionMethod.COUNTERFLOW_CYCLE:
        return _is_robust_counterflow(graph)
    if method == DetectionMethod.ADVANCED_CYCLE:
        return _is_robust_advanced(graph)
    raise RuntimeError("Unknown DetectionMethod")


def _is_robust_counterflow(graph: SummaryGraph) -> bool:
    """Not robust if cycle with a counteflow edge exists"""
    reachable = _compute_reachability(graph)
    for edge in graph.edges:
        if edge.is_counterflow:
            pair = (edge.target, edge.source)
            if reachable[(pair)]:
                return False
    return True


def _is_robust_advanced(graph: SummaryGraph) -> bool:
    reachable = _compute_reachability(graph)
    # timing = timeit.timeit(lambda: _compute_reachability(graph),
    #                        number=1, globals=globals())
    # print(f"reachability construction: {timing:.2f}s")
    # Robustness check:
    # e1 is the non-counterflow edge
    for e1 in graph.non_counterflow_edges:
        # e2 is the counterflow edge immediately after e1
        for e2 in graph.outgoing_counterflow_edges[e1.target]:
            # if we can close the cycle, check for non-counterflow + counterflow requirements
            if reachable[(e2.target, e1.source)]:
                # position requirements
                if e2.source_query.position < e1.target_query.position:
                    return False
                # e1 is (predicate) rw-antidependency that is not a ww-dependency (e1.source_query is select operation, or predicate based operation)
                if len(e1.source_query.modification_set) == 0 or len(e1.source_query.predicate_set) > 0:
                    return False
            #  two adjacent counterflow edges e2 and e3:
            for e3 in graph.outgoing_counterflow_edges[e2.target]:
                # source e1 reachable from target e3
                if reachable[(e3.target, e1.source)]:
                    return False

    return True


# def _is_robust_advanced(graph: SummaryGraph) -> bool:
#     reachable = _compute_reachability(graph)
#     # Robustness check:
#     for e1 in graph.non_counterflow_edges:
#         # e1 is the not-counterflow edge
#         #if e1.is_counterflow:
#         #    continue
#         for e2 in graph.edges:
#             # possible to reach source e2 from target e1
#             if reachable[(e1.target, e2.source)]:
#                 for e3 in graph.outgoing_counterflow_edges[e2.target]:
#                     # e2 and e3 are the adjacent edges, and source e1 reachable from target e3
#                     if  reachable[(e3.target, e1.source)]: #and e2.target == e3.source
#                         # either e2 and e3 are both counterflow
#                         if e2.is_counterflow: # and e3.is_counterflow:
#                             return False
#                             #print("2 counterflow edges", e1, e2, e3)
#                         # or e3 is counterflow + position requirements
#                         elif e3.source_query.position < e2.target_query.position: #and e3.is_counterflow
#                             return False
#                             #print("1 counterflow edge", e1, e2, e3)
#                         # or e3 is counterflow + position not needed, but e2 is (predicate) rw-antidependency that is not a ww-dependency (e2.source_query is select operation, or predicate based operation)
#                         elif len(e2.source_query.modification_set) == 0 or len(e2.source_query.predicate_set) > 0:
#                             #print("new edge :(")
#                             return False

#     return True


# def _is_robust_advanced(graph: SummaryGraph) -> bool:
#     reachable = _compute_reachability(graph)
#     # Robustness check:
#     for e1 in graph.edges:
#         # e1 is the not-counterflow edge
#         if e1.is_counterflow:
#             continue
#         for e2 in graph.edges:
#             # possible to reach source e2 from target e1
#             if reachable[(e1.target, e2.source)]:
#                 for e3 in graph.outgoing_edges[e2.target]:
#                     # e2 and e3 are the adjacent edges, and source e1 reachable from target e3
#                     if e2.target == e3.source and reachable[(e3.target, e1.source)]:
#                         # either e2 and e3 are both counterflow
#                         if e2.is_counterflow and e3.is_counterflow:
#                             return False
#                             #print("2 counterflow edges", e1, e2, e3)
#                         # or e3 is counterflow + position requirements
#                         elif e3.is_counterflow and e3.source_query.position < e2.target_query.position:
#                             return False
#                             #print("1 counterflow edge", e1, e2, e3)
#     return True


def _compute_reachability(graph: SummaryGraph) -> Dict[Tuple[Node, Node], bool]:
    # Construct reachability info
    reachable = {(n1, n2): False for n1 in graph.nodes for n2 in graph.nodes}
    for edge in graph.edges:
        reachable[(edge.source, edge.target)] = True
    ordered_nodes = list(graph.nodes)
    for k in ordered_nodes:
        for i in ordered_nodes:
            for j in ordered_nodes:
                reachable[(i, j)] = reachable[(i, j)] or (reachable[(i, k)] and reachable[(k, j)])
    return reachable

# def _compute_reachability(graph: SummaryGraph) -> Dict[Tuple[Node, Node], bool]:
#     # Construct reachability info
#     reachable = {(n1, n2): False for n1 in graph.nodes for n2 in graph.nodes}
#     for edge in graph.edges:
#         reachable[(edge.source, edge.target)] = True
#     changed = True
#     while changed:
#         changed = False
#         for (n1, n2), reach12 in reachable.items():
#             if not reach12:
#                 continue
#             for (n3, n4), reach34 in reachable.items():
#                 if reach34 and n2 == n3:
#                     pair = (n1, n4)
#                     if not reachable[pair]:
#                         changed = True
#                         reachable[pair] = True
#     return reachable
