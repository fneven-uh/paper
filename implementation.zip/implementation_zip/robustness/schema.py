from __future__ import annotations
from dataclasses import dataclass, field
from typing import List


@dataclass(frozen=True)
class Attribute:
    name: str
    relation: Relation


@dataclass
class Relation:
    name: str
    attributes: List[Attribute] = field(default_factory=list)

    def add_attribute(self, attr_name: str) -> Attribute:
        attribute = Attribute(attr_name, self)
        self.attributes.append(attribute)
        return attribute

    def __hash__(self) -> int:
        return hash(self.name)

@dataclass
class ForeignKey:
    source: Relation
    target: Relation


@dataclass
class Schema:
    relations: List[Relation]
    foreign_keys: List[ForeignKey]
