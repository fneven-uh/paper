from .schema import Schema, Relation, ForeignKey
from .program import QueryType, BTProgramFactory

# Create schema
account_rel = Relation("Account")
acc_name = account_rel.add_attribute("Name")
acc_customerid = account_rel.add_attribute("CustomerId")

savings_rel = Relation("Savings")
sav_customerid = savings_rel.add_attribute("CustomerId")
sav_balance = savings_rel.add_attribute("Balance")

checking_rel = Relation("Checking")
che_customerid = checking_rel.add_attribute("CustomerId")
che_balance = checking_rel.add_attribute("Balance")

fk_acc_sav = ForeignKey(account_rel, savings_rel)
fk_acc_che = ForeignKey(account_rel, checking_rel)
fk_sav_acc = ForeignKey(savings_rel, account_rel)
fk_che_acc = ForeignKey(checking_rel, account_rel)

sb_relations = [account_rel, savings_rel, checking_rel]
sb_foreignkeys = [fk_acc_sav, fk_acc_che, fk_sav_acc, fk_che_acc]
schema = Schema(sb_relations, sb_foreignkeys)

# Create programs
bal_f = BTProgramFactory("Balance")
q1 = bal_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q2 = bal_f.add_query(QueryType.SELECT, savings_rel,
                     observation_set={sav_balance})
q3 = bal_f.add_query(QueryType.SELECT, checking_rel,
                     observation_set={che_balance})
bal_f.add_fk_constraint(q1, q2, fk_acc_sav)
bal_f.add_fk_constraint(q1, q3, fk_acc_che)
bal_f.add_fk_constraint(q2, q1, fk_sav_acc)
bal_f.add_fk_constraint(q3, q1, fk_che_acc)
balance = bal_f.create_program()

ama_f = BTProgramFactory("Amalgamate")
q1 = ama_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q2 = ama_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q3 = ama_f.add_query(QueryType.UPDATE, savings_rel,
                     observation_set={sav_balance},
                     modification_set={sav_balance})
q4 = ama_f.add_query(QueryType.UPDATE, checking_rel,
                     observation_set={che_balance},
                     modification_set={che_balance})
q5 = ama_f.add_query(QueryType.UPDATE, checking_rel,
                     observation_set={che_balance},
                     modification_set={che_balance})
ama_f.add_fk_constraint(q1, q3, fk_acc_sav)
ama_f.add_fk_constraint(q1, q4, fk_acc_che)
ama_f.add_fk_constraint(q3, q1, fk_sav_acc)
ama_f.add_fk_constraint(q4, q1, fk_che_acc)
ama_f.add_fk_constraint(q2, q5, fk_acc_che)
ama_f.add_fk_constraint(q5, q2, fk_che_acc)
amalgamate = ama_f.create_program()

dep_f = BTProgramFactory("DepositChecking")
q1 = dep_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q2 = dep_f.add_query(QueryType.UPDATE, checking_rel,
                     observation_set={che_balance},
                     modification_set={che_balance})
dep_f.add_fk_constraint(q1, q2, fk_acc_che)
dep_f.add_fk_constraint(q2, q1, fk_che_acc)
depositchecking = dep_f.create_program()

tra_f = BTProgramFactory("TransactSavings")
q1 = tra_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q2 = tra_f.add_query(QueryType.UPDATE, savings_rel,
                     observation_set={sav_balance},
                     modification_set={sav_balance})
tra_f.add_fk_constraint(q1, q2, fk_acc_sav)
tra_f.add_fk_constraint(q2, q1, fk_sav_acc)
transactsavings = tra_f.create_program()

wri_f = BTProgramFactory("WriteCheck")
q1 = wri_f.add_query(QueryType.SELECT, account_rel,
                     observation_set={acc_customerid})
q2 = wri_f.add_query(QueryType.SELECT, savings_rel,
                     observation_set={sav_balance})
q3 = wri_f.add_query(QueryType.SELECT, checking_rel,
                     observation_set={che_balance})
q4 = wri_f.add_query(QueryType.UPDATE, checking_rel,
                     observation_set={che_balance},
                     modification_set={che_balance})
wri_f.add_fk_constraint(q1, q2, fk_acc_sav)
wri_f.add_fk_constraint(q1, q3, fk_acc_che)
wri_f.add_fk_constraint(q2, q1, fk_sav_acc)
wri_f.add_fk_constraint(q3, q1, fk_che_acc)
wri_f.add_fk_constraint(q1, q4, fk_acc_che)
wri_f.add_fk_constraint(q4, q1, fk_che_acc)
writecheck = wri_f.create_program()

programs = {balance, amalgamate, depositchecking, transactsavings, writecheck}
