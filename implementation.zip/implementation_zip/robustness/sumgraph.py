from dataclasses import dataclass, field
from typing import Dict, Set
from .program import ForeignKeyConstr, Program, Query, QueryType


@dataclass
class Node:
    program: Program
    label: str = field(init=False)

    def __post_init__(self):
        self.label = self.program.name

    def __hash__(self) -> int:
        return hash(self.label)


@dataclass(frozen=True)
class Edge:
    source: Node
    target: Node
    source_query: Query
    target_query: Query
    is_counterflow: bool


@dataclass
class SummaryGraph:
    nodes: Set[Node]
    edges: Set[Edge]
    counterflow_edges: Set[Edge] = field(init=False)
    non_counterflow_edges: Set[Edge] = field(init=False)
    outgoing_edges: Dict[Node, Set[Edge]] = field(init=False)
    outgoing_counterflow_edges: Dict[Node, Set[Edge]] = field(init=False)

    def __post_init__(self) -> None:
        self.outgoing_edges = {node: set() for node in self.nodes}
        self.outgoing_counterflow_edges = {node: set() for node in self.nodes}
        self.counterflow_edges = set()
        self.non_counterflow_edges = set()
        for edge in self.edges:
            self.outgoing_edges[edge.source].add(edge)
            if edge.is_counterflow:
                self.counterflow_edges.add(edge)
                self.outgoing_counterflow_edges[edge.source].add(edge)
            else:
                self.non_counterflow_edges.add(edge)



def construct_summary_graph(programs: Set[Program]) -> SummaryGraph:
    nodes_lookup = {prog: Node(prog) for prog in programs}
    edges: Set[Edge] = set()

    for prog1 in programs:
        for prog2 in programs:
            for q1 in prog1.queries:
                for q2 in prog2.queries:
                    _test_edge(
                        prog1, q1, nodes_lookup[prog1], prog2, q2, nodes_lookup[prog2], edges)

    return SummaryGraph(set(nodes_lookup.values()), edges)


def _test_edge(
    prog1: Program, q1: Query, node1: Node,
    prog2: Program, q2: Query, node2: Node,
    edges: Set[Edge]
) -> None:
    # must be over same relation
    if q1.relation != q2.relation:
        return

    # ww-dep
    if len(q1.modification_set & q2.modification_set) > 0\
            and q1.querytype != QueryType.DELETE and q2.querytype != QueryType.INSERT:
        edges.add(Edge(node1, node2, q1, q2, False))

    # wr-dep
    if len(q1.modification_set & q2.observation_set) > 0\
            and q1.querytype != QueryType.DELETE:
        edges.add(Edge(node1, node2, q1, q2, False))

    # predicate wr-dep
    if len(q1.modification_set & q2.predicate_set) > 0:
        # and q1.querytype != QueryType.DELETE:
        edges.add(Edge(node1, node2, q1, q2, False))

    # rw-antidep
    if len(q1.observation_set & q2.modification_set) > 0\
            and q2.querytype != QueryType.INSERT:
        edges.add(Edge(node1, node2, q1, q2, False))
        # counterflow only possible if q1 does not modify tuple (otherwise dirty write)
        if len(q1.modification_set) == 0 and _check_cntrflw_constr(prog1, q1, prog2, q2):
            #print((prog1, q1[0], "crw", q2[0], prog2))
            edges.add(Edge(node1, node2, q1, q2, True))

    # predicate rw-antidep
    if len(q1.predicate_set & q2.modification_set) > 0:
        edges.add(Edge(node1, node2, q1, q2, False))
        edges.add(Edge(node1, node2, q1, q2, True))


def _check_cntrflw_constr(prog1: Program, q1: Query, prog2: Program, q2: Query) -> bool:
    """Returns False if counterflow is not possible due to constraints, and True otherwise."""
    constraints1 = [
        c for c in prog1.constraints if _is_interesting_constraint(q1, c)]
    constraints2 = [
        c for c in prog2.constraints if _is_interesting_constraint(q2, c)]

    for constr1 in constraints1:
        for constr2 in constraints2:
            # should be same foreign key
            if constr1.foreign_key == constr2.foreign_key:
                # implied dirty write detected
                return False

    # Cannot detect that counterflow is impossible
    return True


def _is_interesting_constraint(query: Query, constraint: ForeignKeyConstr) -> bool:
    # Constraint is only interesting if:
    # - corresponding query as source
    if constraint.source != query:
        return False
    # - target query occurs before source query
    if constraint.target.position > constraint.source.position:
        return False
    # - target query updates the tuple (i.e. takes a lock)
    if constraint.target.querytype == QueryType.SELECT:
        return False
    return True
