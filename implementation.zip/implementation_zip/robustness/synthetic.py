"""
Relations:
Buyer(id, calls)
    Primary key: Buyer.id
Bids(buyerId, bid)
    Primary key: Bids.buyerId
    Foreign key "BidsToBuyer": Bids.buyerId references Buyer.id
Log(id, buyerId, bid)
    Primary key: Log.id
    Foreign key "LogToBuyer": Log.buyerId references Buyer.id

Setting:
    For an auction, buyers can interact with an API
    to make bids or collect information on current bids.
    For each buyer, the total number of API calls so far is logged.
    Alls Bids are logged in the relation Log.

Programs:

P1: FindBids(:buyerId, :minBid)
    -> Retrieve all bids above a specified threshold.

    UPDATE Buyer
    SET calls = calls + 1
    WHERE id = :buyerId;

    SELECT bid
    FROM Bids
    WHERE bid >= :minbid;

    COMMIT;

P2: PlaceBid(:buyerId, :bid)
    -> Place a bid. First, the current bid of the buyer is retrieved.
       If the current bid of this buyer is higher, the value is replaced.
       For logging purposes, the proposed bid is always stored in the relation Log

    UPDATE Buyer
    SET calls = calls + 1
    WHERE id = :buyerId;

    SELECT bid into :currentBid
    FROM Bids
    WHERE buyerId = :buyerId;

    IF :currentBid < :bid:

        UPDATE Bids
        SET bid = :bid
        WHERE buyerId = :buyerId;
    
    :logId = uniqueLogId()
    INSERT INTO Log
    VALUES(:logId, :buyerId, :bid);

    COMMIT;
"""

from typing import Set, Tuple
from .schema import ForeignKey, Relation, Schema
from .program import BTProgramFactory, QueryType, BTProgram


# # Create schema
# buyer = Relation("Buyer")
# bu_id = buyer.add_attribute("id")
# bu_calls = buyer.add_attribute("calls")

# bids = Relation("Bids")
# bi_buyer_id = bids.add_attribute("buyerId")
# bi_bid = bids.add_attribute("bid")

# fk_bids_buyer = ForeignKey(bids, buyer)
# schema = Schema([buyer, bids], [fk_bids_buyer])

# # Create programs
# fb_f = ProgramFactory("FindBids")
# q1 = fb_f.add_query(QueryType.UPDATE, buyer,
#                     observation_set={bu_calls},
#                     modification_set={bu_calls})
# q2 = fb_f.add_query(QueryType.SELECT, bids,
#                     observation_set={bi_bid},
#                     predicate_set={bi_bid})
# find_bids = fb_f.create_program()

# #if-version of Placebid
# pb_if_f = ProgramFactory("PlaceBid_If")
# q1 = pb_if_f.add_query(QueryType.UPDATE, buyer,
#                        observation_set={bu_calls},
#                        modification_set={bu_calls})
# q2 = pb_if_f.add_query(QueryType.SELECT, bids,
#                        observation_set={bi_bid})
# q3 = pb_if_f.add_query(QueryType.UPDATE, bids,
#                        observation_set=set(), #Note: bid is replaced, so no need to observe old bid
#                        modification_set={bi_bid})
# pb_if_f.add_fk_constraint(q2, q1, fk_bids_buyer)
# pb_if_f.add_fk_constraint(q3, q1, fk_bids_buyer)
# place_bid_if = pb_if_f.create_program()

# #else-version of Placebid (new bid is lower, so not replaced)
# pb_el_f = ProgramFactory("PlaceBid_Else")
# q1 = pb_el_f.add_query(QueryType.UPDATE, buyer,
#                        observation_set={bu_calls},
#                        modification_set={bu_calls})
# q2 = pb_el_f.add_query(QueryType.SELECT, bids,
#                        observation_set={bi_bid})
# pb_el_f.add_fk_constraint(q2, q1, fk_bids_buyer)
# place_bid_else = pb_el_f.create_program()

# programs = {find_bids, place_bid_if, place_bid_else}


def create_scaled_program(scaling_factor: int) -> Tuple[Schema, Set[BTProgram]]:
    buyer = Relation("Buyer")
    bu_id = buyer.add_attribute("id")
    bu_calls = buyer.add_attribute("calls")

    log = Relation("Log")
    lo_id = log.add_attribute("id")
    lo_buyer_id = log.add_attribute("buyerId")
    lo_bid = log.add_attribute("bid")
    fk_log_buyer = ForeignKey(log, buyer)

    relations = [buyer, log]
    fk_constraints = [fk_log_buyer]
    programs: Set[BTProgram] = set()

    for i in range(1, scaling_factor+1):
        # Add to schema
        bids = Relation(f"Bids_{i}")
        bi_buyer_id = bids.add_attribute("buyerId")
        bi_bid = bids.add_attribute("bid")
        fk_bids_buyer = ForeignKey(bids, buyer)
        relations.append(bids)
        fk_constraints.append(fk_bids_buyer)

        # Create programs
        fb_f = BTProgramFactory(f"FindBids_{i}_")
        q1 = fb_f.add_query(QueryType.UPDATE, buyer,
                            observation_set={bu_calls},
                            modification_set={bu_calls})
        q2 = fb_f.add_query(QueryType.SELECT, bids,
                            observation_set={bi_bid},
                            predicate_set={bi_bid})
        find_bids = fb_f.create_program()

        # if-version of Placebid
        pb_if_f = BTProgramFactory(f"PlaceBid_{i}_")
        q1 = pb_if_f.add_query(QueryType.UPDATE, buyer,
                               observation_set={bu_calls},
                               modification_set={bu_calls})
        q2 = pb_if_f.add_query(QueryType.SELECT, bids,
                               observation_set={bi_bid})
        pb_if_f.start_if()
        q3 = pb_if_f.add_query(QueryType.UPDATE, bids,
                               observation_set=set(),  # Note: bid is replaced, so no need to observe old bid
                               modification_set={bi_bid})
        pb_if_f.end_if()
        q4 = pb_if_f.add_query(QueryType.INSERT, log,
                               modification_set={lo_id, lo_buyer_id, lo_bid})
        pb_if_f.add_fk_constraint(q2, q1, fk_bids_buyer)
        pb_if_f.add_fk_constraint(q3, q1, fk_bids_buyer)
        pb_if_f.add_fk_constraint(q4, q1, fk_log_buyer)
        place_bid_if = pb_if_f.create_program()

        # else-version of Placebid (new bid is lower, so not replaced)
        # pb_el_f = ProgramFactory(f"PlaceBid_Else_{i}")
        # q1 = pb_el_f.add_query(QueryType.UPDATE, buyer,
        #                        observation_set={bu_calls},
        #                        modification_set={bu_calls})
        # q2 = pb_el_f.add_query(QueryType.SELECT, bids,
        #                        observation_set={bi_bid})
        # q3 = pb_el_f.add_query(QueryType.INSERT, log,
        #                        modification_set={lo_id, lo_buyer_id, lo_bid})
        # pb_el_f.add_fk_constraint(q2, q1, fk_bids_buyer)
        # pb_el_f.add_fk_constraint(q3, q1, fk_log_buyer)
        # place_bid_else = pb_el_f.create_program()

        programs.add(find_bids)
        programs.add(place_bid_if)
        #programs.add(place_bid_else)

    schema = Schema(relations, fk_constraints)
    return (schema, programs)

# SELECT = "SELECT"
# UPDATE = "UPDATE"
# INSERT = "INSERT"
# DELETE = "DELETE"

# R1 = "R1"
# a1 = "a1"
# R2 = "R2"
# a2 = "a2"
# R3 = "R3"
# a3 = "a3"


# programs = {
#     "P1": [
#         (1, UPDATE, R1, [a1], [a1], []),
#         (2, SELECT, R2, [a2], [], [])
#     ],
#     "P2": [
#         (1, UPDATE, R1, [a1], [a1], []),
#         (2, UPDATE, R2, [a2], [a2], [])
#     ],
#     "P3": [
#         (1, UPDATE, R1, [a1], [a1], []),
#         (2, SELECT, R3, [a3], [], [])
#     ],
#     "P4": [
#         (1, UPDATE, R1, [a1], [a1], []),
#         (2, UPDATE, R3, [a3], [a3], [])
#     ]
# }

# # Keep track of implied tuples that are written to earlier in the transaction.
# func_constr = {
# }
