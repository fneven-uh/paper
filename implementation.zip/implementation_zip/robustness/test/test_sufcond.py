import itertools

from robustness.program import unfold_programset
from .. import robustsufcond as rsc
from .. import sumgraph as sg
from .. import smallbank as sb
from .. import tpcc
from .. import synthetic


def test_smallbank():
    maximal_robust_subsets = [
        {sb.amalgamate, sb.depositchecking, sb.transactsavings},
        {sb.balance, sb.depositchecking},
        {sb.balance, sb.transactsavings}
    ]
    for size in range(1, len(sb.programs) + 1):
        for progset in map(set, itertools.combinations(sb.programs, size)):
            linear_progs = unfold_programset(progset)
            graph = sg.construct_summary_graph(linear_progs)
            detected_robust = rsc.is_robust(
                graph, rsc.DetectionMethod.ADVANCED_CYCLE)
            is_robust = any(progset.issubset(s)
                            for s in maximal_robust_subsets)
            assert detected_robust == is_robust


def test_tpcc():
    maximal_robust_subsets = [
        {tpcc.p_payment, tpcc.p_order_status, tpcc.p_stock_level},
        {tpcc.p_new_order, tpcc.p_payment}
    ]
    for size in range(1, len(tpcc.programs) + 1):
        for progset in map(set, itertools.combinations(tpcc.programs, size)):
            linear_progs = unfold_programset(progset)
            graph = sg.construct_summary_graph(linear_progs)
            detected_robust = rsc.is_robust(
                graph, rsc.DetectionMethod.ADVANCED_CYCLE)
            is_robust = any(progset.issubset(s)
                            for s in maximal_robust_subsets)
            assert detected_robust == is_robust


def test_synthetic():
    _, btprograms = synthetic.create_scaled_program(1)
    programs = unfold_programset(btprograms)
    graph = sg.construct_summary_graph(programs)
    detected_robust = rsc.is_robust(graph, rsc.DetectionMethod.ADVANCED_CYCLE)
    assert detected_robust

    _, btprograms = synthetic.create_scaled_program(5)
    programs = unfold_programset(btprograms)
    graph = sg.construct_summary_graph(programs)
    detected_robust = rsc.is_robust(graph, rsc.DetectionMethod.ADVANCED_CYCLE)
    assert detected_robust
