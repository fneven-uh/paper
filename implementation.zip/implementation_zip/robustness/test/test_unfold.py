from .. import program as pg
from .. import schema as sc

def test_unfold():
    rel = sc.Relation("R")
    attr = rel.add_attribute("a")
    fk = sc.ForeignKey(rel, rel)
    schema = sc.Schema([rel], [fk])
    q1 = pg.Query(1, pg.QueryType.UPDATE, rel, {attr}, {attr}, set())
    q2 = pg.Query(1, pg.QueryType.SELECT, rel, {attr}, set(), set())
    q3 = pg.Query(1, pg.QueryType.DELETE, rel, set(), {attr}, {attr})
    loop = pg.BTPLoop([pg.BTPBranch([q2], [q3])])
    prog = pg.BTProgram("test", [q1, loop], [pg.ForeignKeyConstr(q2, q1, fk)])
    unfolded = pg.unfolded(prog)
    assert(len(unfolded)) == 7
