from .schema import Schema, Relation, ForeignKey
from .program import QueryType, BTProgramFactory

# TODO: remove these hardcoded strings
SELECT = "SELECT"
UPDATE = "UPDATE"
INSERT = "INSERT"
DELETE = "DELETE"

# Create schema
warehouse = Relation("warehouse")
w_id = warehouse.add_attribute("w_id")
w_name = warehouse.add_attribute("w_name")
w_street_1 = warehouse.add_attribute("w_street_1")
w_street_2 = warehouse.add_attribute("w_street_2")
w_city = warehouse.add_attribute("w_city")
w_state = warehouse.add_attribute("w_state")
w_zip = warehouse.add_attribute("w_zip")
w_tax = warehouse.add_attribute("w_tax")
w_ytd = warehouse.add_attribute("w_ytd")

district = Relation("District")
d_id = district.add_attribute("d_id")
d_w_id = district.add_attribute("d_w_id")
d_name = district.add_attribute("d_name")
d_street_1 = district.add_attribute("d_street_1")
d_street_2 = district.add_attribute("d_street_2")
d_city = district.add_attribute("d_city")
d_state = district.add_attribute("d_state")
d_zip = district.add_attribute("d_zip")
d_tax = district.add_attribute("d_tax")
d_ytd = district.add_attribute("d_ytd")
d_next_o_id = district.add_attribute("d_next_o_id")

customer = Relation("Customer")
c_id = customer.add_attribute("c_id")
c_d_id = customer.add_attribute("c_d_id")
c_w_id = customer.add_attribute("c_w_id")
c_first = customer.add_attribute("c_first")
c_middle = customer.add_attribute("c_middle")
c_last = customer.add_attribute("c_last")
c_street_1 = customer.add_attribute("c_street_1")
c_street_2 = customer.add_attribute("c_street_2")
c_city = customer.add_attribute("c_city")
c_state = customer.add_attribute("c_state")
c_zip = customer.add_attribute("c_zip")
c_phone = customer.add_attribute("c_phone")
c_since = customer.add_attribute("c_since")
c_credit = customer.add_attribute("c_credit")
c_credit_lim = customer.add_attribute("c_credit_lim")
c_discount = customer.add_attribute("c_discount")
c_balance = customer.add_attribute("c_balance")
c_ytd_payment = customer.add_attribute("c_ytd_payment")
c_payment_cnt = customer.add_attribute("c_payment_cnt")
c_delivery_cnt = customer.add_attribute("c_delivery_cnt")
c_data = customer.add_attribute("c_data")

history = Relation("History")
h_c_id = history.add_attribute("h_c_id")
h_c_d_id = history.add_attribute("h_c_d_id")
h_c_w_id = history.add_attribute("h_c_w_id")
h_d_id = history.add_attribute("h_d_id")
h_w_id = history.add_attribute("h_w_id")
h_date = history.add_attribute("h_date")
h_amount = history.add_attribute("h_amount")
h_data = history.add_attribute("h_data")

new_order = Relation("New_Order")
no_o_id = new_order.add_attribute("no_o_id")
no_d_id = new_order.add_attribute("no_d_id")
no_w_id = new_order.add_attribute("no_w_id")

orders = Relation("Orders")
o_id = orders.add_attribute("o_id")
o_d_id = orders.add_attribute("o_d_id")
o_w_id = orders.add_attribute("o_w_id")
o_c_id = orders.add_attribute("o_c_id")
o_entry_id = orders.add_attribute("o_entry_id")
o_carrier_id = orders.add_attribute("o_carrier_id")
o_ol_cnt = orders.add_attribute("o_ol_cnt")
o_all_local = orders.add_attribute("o_all_local")

order_line = Relation("Order_Line")
ol_o_id = order_line.add_attribute("ol_o_id")
ol_d_id = order_line.add_attribute("ol_d_id")
ol_w_id = order_line.add_attribute("ol_w_id")
ol_number = order_line.add_attribute("ol_number")
ol_i_id = order_line.add_attribute("ol_i_id")
ol_supply_w_id = order_line.add_attribute("ol_supply_w_id")
ol_delivery_d = order_line.add_attribute("ol_delivery_d")
ol_quantity = order_line.add_attribute("ol_quantity")
ol_amount = order_line.add_attribute("ol_amount")
ol_dist_info = order_line.add_attribute("ol_dist_info")

item = Relation("Item")
i_id = item.add_attribute("i_id")
i_im_id = item.add_attribute("i_im_id")
i_name = item.add_attribute("i_name")
i_price = item.add_attribute("i_price")
i_data = item.add_attribute("i_data")

stock = Relation("Stock")
s_i_id = stock.add_attribute("s_i_id")
s_w_id = stock.add_attribute("s_w_id")
s_quantity = stock.add_attribute("s_quantity")
s_dist_01 = stock.add_attribute("s_dist_01")
s_dist_02 = stock.add_attribute("s_dist_02")
s_dist_03 = stock.add_attribute("s_dist_03")
s_dist_04 = stock.add_attribute("s_dist_04")
s_dist_05 = stock.add_attribute("s_dist_05")
s_dist_06 = stock.add_attribute("s_dist_06")
s_dist_07 = stock.add_attribute("s_dist_07")
s_dist_08 = stock.add_attribute("s_dist_08")
s_dist_09 = stock.add_attribute("s_dist_09")
s_dist_10 = stock.add_attribute("s_dist_10")
s_ytd = stock.add_attribute("s_ytd")
s_order_cnt = stock.add_attribute("s_order_cnt")
s_remote_cnt = stock.add_attribute("s_remote_cnt")
s_data = stock.add_attribute("s_data")

fk_cust_wh = ForeignKey(customer, warehouse)

tpcc_relations = [warehouse, district, customer, history,
                  new_order, orders, order_line, item, stock]
tpcc_foreignkeys = [fk_cust_wh]
schema = Schema(tpcc_relations, tpcc_foreignkeys)

# Create programs
no_f = BTProgramFactory("NewOrder")
q1 = no_f.add_query(QueryType.SELECT, customer,
                     observation_set={c_discount, c_last, c_credit})
q2 = no_f.add_query(QueryType.SELECT, warehouse,
                     observation_set={w_tax})
q3 = no_f.add_query(QueryType.UPDATE, district,
                     observation_set={d_next_o_id, d_tax},
                     modification_set={d_next_o_id})
q4 = no_f.add_query(QueryType.INSERT, orders,
                    modification_set={o_id, o_d_id, o_w_id, o_c_id, o_entry_id, o_ol_cnt, o_all_local})
q5 = no_f.add_query(QueryType.INSERT, new_order,
                    modification_set={no_o_id, no_d_id, no_w_id})
no_f.start_loop()
# iteration 1
q6 = no_f.add_query(QueryType.SELECT, item,
                    observation_set={i_price, i_name, i_data})
q7 = no_f.add_query(QueryType.UPDATE, stock,
                    observation_set={s_quantity, s_ytd, s_order_cnt, s_remote_cnt, s_data, s_dist_01, s_dist_02, s_dist_03, s_dist_04, s_dist_05, s_dist_06, s_dist_07, s_dist_08, s_dist_09, s_dist_10},
                    modification_set={s_quantity, s_ytd, s_order_cnt, s_remote_cnt})
q8 = no_f.add_query(QueryType.INSERT, order_line,
                    modification_set={ol_o_id, ol_d_id, ol_w_id, ol_w_id, ol_number, ol_i_id, ol_supply_w_id, ol_quantity, ol_amount, ol_dist_info})
no_f.end_loop()
# iteration 2
# q9 = no_f.add_query(QueryType.SELECT, item,
#                     observation_set={i_price, i_name, i_data})
# q10 = no_f.add_query(QueryType.UPDATE, stock,
#                     observation_set={s_quantity, s_ytd, s_order_cnt, s_remote_cnt, s_data, s_dist_01, s_dist_02, s_dist_03, s_dist_04, s_dist_05, s_dist_06, s_dist_07, s_dist_08, s_dist_09, s_dist_10},
#                     modification_set={s_quantity, s_ytd, s_order_cnt, s_remote_cnt})
# q11 = no_f.add_query(QueryType.INSERT, order_line,
#                     modification_set={ol_o_id, ol_d_id, ol_w_id, ol_w_id, ol_number, ol_i_id, ol_supply_w_id, ol_quantity, ol_amount, ol_dist_info})
no_f.add_fk_constraint(q1, q2, fk_cust_wh)
p_new_order = no_f.create_program()

pa_f = BTProgramFactory("Payment")
q1 = pa_f.add_query(QueryType.UPDATE, warehouse,
                    observation_set={w_ytd, w_street_1, w_street_2, w_city, w_state, w_zip, w_name},
                    modification_set={w_ytd})
q2 = pa_f.add_query(QueryType.UPDATE, district,
                    observation_set={d_ytd, d_street_1, d_street_2, d_city, d_state, d_zip, d_name},
                    modification_set={d_ytd})
# next one is under if-statement
pa_f.start_if()
q3 = pa_f.add_query(QueryType.SELECT, customer,
                    observation_set={c_id},
                    predicate_set={c_w_id, c_d_id, c_last})
pa_f.end_if()
q4 = pa_f.add_query(QueryType.UPDATE, customer,
                    observation_set={c_first, c_middle, c_last, c_street_1, c_street_2, c_city, c_state, c_zip, c_phone, c_credit, c_credit_lim, c_discount, c_balance, c_since, c_ytd_payment, c_ytd_payment},
                    modification_set={c_balance, c_ytd_payment, c_payment_cnt})
# next two are under if-statement
pa_f.start_if()
q5 = pa_f.add_query(QueryType.SELECT, customer,
                    observation_set={c_data})
q6 = pa_f.add_query(QueryType.UPDATE, customer,
                    modification_set={c_data})
pa_f.end_if()
q7 = pa_f.add_query(QueryType.INSERT, history,
                    modification_set={h_c_d_id, h_c_w_id, h_c_id, h_d_id, h_w_id, h_date, h_amount, h_data})
pa_f.add_fk_constraint(q5, q1, fk_cust_wh)
pa_f.add_fk_constraint(q6, q1, fk_cust_wh)
p_payment = pa_f.create_program()

os_f = BTProgramFactory("OrderStatus")
# Two versions depending on if/else. using the predicate version under if, key version under else
os_f.start_if()
q1 = os_f.add_query(QueryType.SELECT, customer,
                    observation_set={c_balance, c_first, c_middle, c_id},
                    predicate_set={c_last, c_d_id, c_w_id})
os_f.start_else()
q1b = os_f.add_query(QueryType.SELECT, customer,
                    observation_set={c_balance, c_first, c_middle, c_last})
os_f.end_if()
q2 = os_f.add_query(QueryType.SELECT, orders,
                    observation_set={o_id, o_carrier_id, o_entry_id},
                    predicate_set={o_w_id, o_d_id, o_c_id})
q3 = os_f.add_query(QueryType.SELECT, order_line,
                    observation_set={ol_i_id, ol_supply_w_id, ol_quantity, ol_amount, ol_delivery_d},
                    predicate_set={ol_o_id, ol_d_id, ol_w_id})
p_order_status = os_f.create_program()

de_f = BTProgramFactory("Delivery")
# iteration 1
de_f.start_loop()
q1 = de_f.add_query(QueryType.SELECT, new_order,
                    observation_set={no_o_id},
                    predicate_set={no_d_id, no_w_id})
q2 = de_f.add_query(QueryType.DELETE, new_order,
                    modification_set={no_o_id, no_d_id, no_w_id})
q3 = de_f.add_query(QueryType.SELECT, orders,
                    observation_set={o_c_id})
q4 = de_f.add_query(QueryType.UPDATE, orders,
                    modification_set={o_carrier_id})
q5 = de_f.add_query(QueryType.UPDATE, order_line,
                    modification_set={ol_delivery_d},
                    predicate_set={ol_o_id, ol_d_id, ol_w_id})
q6 = de_f.add_query(QueryType.SELECT, order_line,
                    observation_set={ol_amount},
                    predicate_set={ol_o_id, ol_d_id, ol_w_id})
q7 = de_f.add_query(QueryType.UPDATE, customer,
                    observation_set={c_balance, c_delivery_cnt},
                    modification_set={c_balance, c_delivery_cnt})
de_f.end_loop()
# # iteration 2
# q8 = de_f.add_query(QueryType.SELECT, new_order,
#                     observation_set={no_o_id},
#                     predicate_set={no_d_id, no_w_id})
# q9 = de_f.add_query(QueryType.DELETE, new_order,
#                     modification_set={no_o_id, no_d_id, no_w_id})
# q10 = de_f.add_query(QueryType.SELECT, orders,
#                     observation_set={o_c_id})
# q11 = de_f.add_query(QueryType.UPDATE, orders,
#                     modification_set={o_carrier_id})
# q12 = de_f.add_query(QueryType.UPDATE, order_line,
#                     modification_set={ol_delivery_d},
#                     predicate_set={ol_o_id, ol_d_id, ol_w_id})
# q13 = de_f.add_query(QueryType.SELECT, order_line,
#                     observation_set={ol_amount},
#                     predicate_set={ol_o_id, ol_d_id, ol_w_id})
# q14 = de_f.add_query(QueryType.UPDATE, customer,
#                     observation_set={c_balance, c_delivery_cnt},
#                     modification_set={c_balance, c_delivery_cnt})
p_delivery = de_f.create_program()

sl_f = BTProgramFactory("StockLevel")
q1 = sl_f.add_query(QueryType.SELECT, district,
                    observation_set={d_next_o_id})
q2 = sl_f.add_query(QueryType.SELECT, order_line,
                    observation_set={ol_i_id},
                    predicate_set={ol_w_id, ol_d_id, ol_o_id})
q3 = sl_f.add_query(QueryType.SELECT, stock,
                    observation_set={s_i_id},
                    predicate_set={s_w_id, s_quantity})
p_stock_level = sl_f.create_program()

programs = {p_new_order, p_payment, p_order_status, p_delivery, p_stock_level}


# TODO: is this constraint a FK?
func_constr = {
    "equal_no": [("Delivery", 1, 2), ("Delivery", 2, 1), ("Delivery", 8, 9), ("Delivery", 9, 8)]
}
