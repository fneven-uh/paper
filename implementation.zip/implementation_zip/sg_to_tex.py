import itertools
from typing import Set
from robustness.program import BTProgram, Program, Query, unfold_programset
from robustness import sumgraph as sg
from robustness import synthetic
from robustness import smallbank as sb
from robustness import tpcc

TIKZ_NODE_STYLE = "sgnode"
TIKZ_EDGE_STYLE = "sgedge"
TIKZ_COUNTERFLOW_STYLE = "sgcedge"
TIKZ_QNODE_STYLE = "qnode"
def LBL_PREPROCESSING(s: str): return s.replace("_", "")


tpcc_top = ["OrderStatus1", "OrderStatus2", "Payment11", "Payment12", "Payment21", "Payment22"]
tpcc_bottom = ["StockLevel", "NewOrder1", "NewOrder2", "NewOrder3", "Delivery1", "Delivery2", "Delivery3"]
tpcc_pairs = list(itertools.product(tpcc_top, tpcc_bottom))

def start_bend(source: sg.Node, target: sg.Node, is_counterflow: bool) -> int:
    lbl_s = LBL_PREPROCESSING(source.label)
    lbl_t = LBL_PREPROCESSING(target.label)
    
    if (lbl_s, lbl_t) in tpcc_pairs or (lbl_t, lbl_s) in tpcc_pairs:
        return 5 if is_counterflow else 15
    return 20 if is_counterflow else 40

def increase_bend(source: sg.Node, target: sg.Node, is_counterflow: bool) -> int:
    lbl_s = LBL_PREPROCESSING(source.label)
    lbl_t = LBL_PREPROCESSING(target.label)
    
    if (lbl_s, lbl_t) in tpcc_pairs or (lbl_t, lbl_s) in tpcc_pairs:
        return 1
    return 2

def queryname_lookup(q: Query, p: Program) -> str:
    lbl = p.name
    pos = q.position
    if lbl == "FindBids_1":
        return f"q_{pos}"
    if lbl == "PlaceBid_If_1":
        return f"q_{pos+2}"
    if lbl == "PlaceBid_Else_1":
        i = pos + 2
        if i == 5:
            i += 1
        return f"q_{i}"
    return f"q_{pos}"


def convert_edge(edge: sg.Edge, disable_label: bool, bend: int = 40) -> str:
    lbl1 = LBL_PREPROCESSING(edge.source.label)
    lbl2 = LBL_PREPROCESSING(edge.target.label)
    q1 = queryname_lookup(edge.source_query, edge.source.program)
    q2 = queryname_lookup(edge.target_query, edge.target.program)
    edge_lbl = f"${q1} \\rightarrow {q2}$"
    tikz_style = TIKZ_EDGE_STYLE
    bend_style = f"bend left={bend}"
    if edge.is_counterflow:
        tikz_style = TIKZ_COUNTERFLOW_STYLE
        bend_style = f"bend left={bend}"
    if lbl1 == lbl2:
        bend_style = "loop above"
    result = f"\\path[{tikz_style}] ({lbl1}) to[{bend_style}]\n"
    #if disable_label:
    #    result += "%"
    #result += f" node[{TIKZ_QNODE_STYLE},xshift=0,yshift=0] {{{edge_lbl}}}\n"
    result += f" ({lbl2});\n"
    return result


def convert_to_tex(graph: sg.SummaryGraph, disable_edge_labels: bool) -> str:
    result = ""
    for node in graph.nodes:
        lbl = LBL_PREPROCESSING(node.label)
        result += f"\\node[{TIKZ_NODE_STYLE}] ({lbl}) at (0,0) {{{lbl}}};\n"

    node_list = list(sorted(graph.nodes, key=lambda n: n.label))
    for i1, n1 in enumerate(node_list):
        for n2 in node_list[i1:]:
            result += f"% edges between {LBL_PREPROCESSING(n1.label)} and {LBL_PREPROCESSING(n2.label)}\n"
            # first edges from n1 to n2
            bend = start_bend(n1, n2, False)
            for edge in graph.non_counterflow_edges:
                if edge.source == n1 and edge.target == n2:
                    result += convert_edge(edge, disable_edge_labels, bend)
                    bend += increase_bend(n1, n2, False)
            bend = start_bend(n1, n2, True)
            for edge in graph.counterflow_edges:
                if edge.source == n1 and edge.target == n2:
                    result += convert_edge(edge, disable_edge_labels, bend)
                    bend += increase_bend(n1, n2, True)
            # then edges from n1 to n2 (except if n1 == n2)
            if n1 == n2:
                continue
            bend = start_bend(n2, n1, False)
            for edge in graph.non_counterflow_edges:
                if edge.source == n2 and edge.target == n1:
                    result += convert_edge(edge, disable_edge_labels, bend)
                    bend += increase_bend(n2, n1, False)
            bend = start_bend(n2, n1, True)
            for edge in graph.counterflow_edges:
                if edge.source == n2 and edge.target == n1:
                    result += convert_edge(edge, disable_edge_labels, bend)
                    bend += increase_bend(n2, n1, True)
    return result


def create_tex_sumgraph(programs: Set[BTProgram], disable_edge_labels:bool) -> str:
    linear = unfold_programset(programs)
    graph = sg.construct_summary_graph(linear)
    converted = convert_to_tex(graph, disable_edge_labels)
    return converted


def convert_auction_benchmark(n: int) -> None:
    _, programs = synthetic.create_scaled_program(n)
    converted = create_tex_sumgraph(programs, False)
    print(converted)


def convert_smallbank_benchmark() -> None:
    converted = create_tex_sumgraph(sb.programs, True)
    print(converted)


def convert_tpcc_benchmark() -> None:
    converted = create_tex_sumgraph(tpcc.programs, True)
    print(converted)


if __name__ == "__main__":
    convert_auction_benchmark(3)
    #convert_smallbank_benchmark()
    #convert_tpcc_benchmark()